<?php
$con= mysql_connect('localhost', 'sarevok', 'JohnMayL1v3s') or die("Can't connnect to mysql");
mysql_select_db("sarevok",$con) or die("Can't select database");
?>
