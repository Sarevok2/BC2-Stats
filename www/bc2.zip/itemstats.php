<?php

include("connect.php");

$values = array(
	"kills" => "_k",
	"deaths" => "_d",
	"shotsfired" => "_sf",
	"shotshit" => "_sh",
	"timeplayed" => "_t",
	"heals" => "_h",
	"resupplies" => "_r",
	"revives" => "_r"
	"lock" => "_l");

$gadgets = array(
	"40g" => array("kills", "shotsfired", "shotshit", "lock"),
	"ammo" => array("resupplies", "lock"),
	"40s" => array("shotsfired", "lock"),
	"medic" => array("heals", "lock"),
	"def" => array("kills", "revives", "lock"),
	"rpg" => array("kills", "shotsfired", "shotshit", "lock"),
	"repair" => array("kills", "time", "lock"),
	"atm" => array("kills", "shotsfired", "shotshit", "lock"),
	"carl" => array("kills", "shotsfired", "shotshit", "lock"),
	"m136" => array("kills", "shotsfired", "shotshit", "lock"),
	"c4" => array("kills", "time", "lock"),
	"motion" => array("shotsfired", "time", "lock"),
	"mort" => array("kills", "shotsfired", "shotshit", "lock"),
	"kni" => array("kills", "time", "lock"),
	"nade" => array("kills", "time", "lock"),
	"trac" => array("shotsfired", "shotshit", "lock"),
	"bay" => array("kills", "lock"));

$name = $_GET['name'];
$table;
$categories;
$values;
$numvalues;
if ($_GET['type'] == "gun") {
	$table = "gunstats";
	$postfixes = array($name."_k", $name."_sf", $name."_sh", $name."_t", $name."_l");
	$sql = "SELECT ".$postfixes[0].",".$postfixes[1].",".$postfixes[2].",".$postfixes[3].",".$postfixes[4].",max(time) FROM gunstats WHERE persona = " . $_GET['persona'];
   $result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	for ($i=0; $i<5; $i++) {
		$values[$i] = $row[$values[$i]];
	}
	#echo $row[$values[0]] . " " . $row[$values[1]] . " " .$row[$values[2]] . " " .$row[$values[3]] . " " .$row[$values[4]];
}
else echo "wtf";

//echo "qwerqerw: " . $_GET['persona'] . " " . $_GET['type'] . " " . $_GET['name'];
echo "\nstart\n";
echo "<" . $table . ">\n";
for ($i=0; $i<$numvalues; $i++) {
	echo "<" . $categories[$i] . ">" . $values[$i] . "</" . $categories[$i] . ">\n";
}
echo "</" . $table . ">\n";
echo "end";
?>
