function getHTTPObject() {
	if (window.ActiveXObject)
		return new ActiveXObject("Microsoft.XMLHTTP");
	else if (window.XMLHttpRequest)
		return new XMLHttpRequest;
	else {
		alert("Your browser does not support AJAX.");
		return null;
	}
}

function foo() {document.write("wtf");}

function showitemstats(persona, itemName, type) {
	httpObject = getHTTPObject();
	if (httpObject != null) {
		httpObject.open("GET", "itemstats.php?type="+type+"&name="+itemName+"&persona="+persona, true);
		httpObject.send(null);
		httpObject.onreadystatechange = setOutput;
	}
}

function setOutput() {
	if (httpObject.readyState == 4) {
		document.getElementById('outputText').value = httpObject.responseText;
	}
}
