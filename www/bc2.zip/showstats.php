<?php
echo "<html><head><link rel='stylesheet' type='text/css' href='style.css' />";
echo "<script type='text/javascript' src='scripts.js'></script></head><body>";

include("connect.php");

$result = mysql_query("SELECT * FROM mainstats WHERE persona = " . $_GET['persona'])
or die("could not retrieve stats: " . mysql_error());


$numrows = mysql_num_rows($result);
$maxtime = 0;
$maxtimeindex = 0;
for ($i=0; $i<$numrows; $i++) {
	$rows[$i] = mysql_fetch_array($result);
	if ($rows[$i]['time'] > $maxtime) {
		$maxtime  = $rows[$i]['time'];
		$maxtimeindex = $i;
	}
}
$row = $rows[$maxtimeindex];
$kdratio = round($row['kills'] / $row['deaths'],2);
$totalscore = $row['combatscore'] + $row['awardscore'];
$scorepermin = round($totalscore / ($row['timeplayed']/60),2);


echo "<br/>Main Stats<br/>";
echo "<table border=1><tr><th>Last Update</th><th>Position</th><th>Time played</th><th>Kills</th><th>Deaths</th><th>KD Ratio</th><th>Rank</th><th>To Next Rank</th></tr>";
echo "<tr><td>".date("F j, Y, g:i a", $row['time'])."</td><td>".$row['position']."</td><td>".$row['timeplayed']."</td><td>".$row['kills']."</td><td>".$row['deaths']."</td><td>".$kdratio."</td><td>".$row['rank']."</td><td>".$row['nextrankprog']."/".$row['nextrankgoal']."</td></tr></table>";

echo "<br/>Score<br/>";
echo "<table><tr><td><table border=1><tr><th>Assault Score</th><th>Medic Score</th><th>Recon Score</th><th>Engineer Score</th><th>Vehicle Score</th><th>Combat Score</th><th>Award Score</th><th>Total Score</th><th>Score per Min</th></tr>";
echo "<tr><td>".$row['assaultscore']."</td><td>".$row['medicscore']."</td><td>".$row['reconscore']."</td><td>".$row['engiscore']."</td><td>".$row['vehiclescore']."</td><td>".$row['combatscore']."</td><td>".$row['awardscore']."</td><td>".$totalscore."</td><td>".$scorepermin."</td></tr></table></td><td>Gun stats</td></tr></table>";

echo "<br/>Gun Stats<br/>";
echo "<table border=1>";
echo "<tr><th>Assault</th><td><a href='javascript:showitemstats(\"a\", 2,3)'>gun</a></td></tr>";
echo "</table>";
echo "<input type='button' onclick='showitemstats(1,2,\"d\")' value='foo' />";
echo "<input type='text' name='outputText' id='outputText' />";
echo "</body></html>";
?>
